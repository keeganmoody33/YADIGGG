---
title: "yadiggg: Physical Placement Sketch Template"
project: yadiggg
status: active-draft
type: industrial_design_brief
tags: [yadiggg, physical-design, industrial-design, mechanical, kicad]
backlinks:
  - "[[CONTEXT]]"
  - "[[docs/project-state]]"
  - "[[physical-design/physical-direction-brief]]"
---

# yadiggg: Physical Placement Sketch Template

**Date of Document**: Tuesday, June 24, 2026  
**Status**: Working template for physical direction review  
**Purpose**: Convert verbal physical assumptions into a block layout that can drive enclosure and KiCad decisions.

---

## 1. Goal of This Sketch

This is not a final industrial design package. It should answer:

1. Where does the PCB sit within the shell?
2. Where do the controls, display, camera, battery, and ports go?
3. What clearances must exist for battery, lens barrel, shields, and flex cables?
4. What must change in KiCad board outline and component keepouts?

---

## 2. Working Assumptions

- **V1 target envelope**: approximately 105mm x 60mm x 15mm
- **Primary orientation**: portrait-like, one-handable, voice-recorder-like form
- **Primary input**: one main orange scan/control input, thumb-reachable
- **Display**: dominant front-face element, upper region
- **Camera/OCR**: retained for V1 exploration unless feasibility check says otherwise
- **Audio jack**: bottom or side-edge candidate
- **Antenna**: board-edge corner zone with keepout
- **Battery**: largest internal volume element

---

## 3. Sketch Template

### 3.1 Front View

```text
+---------------------------------------------------+
|                                                   |
|                 [DISPLAY WINDOW]                  |
|                                                   |
|      [LOGO / BRAND MARK - DEFERRED / OPTIONAL]   |
|                                                   |
|        [FRONT FACE: minimal visible hardware]     |
|                                                   |
+---------------------------------------------------+
```

### 3.2 Rear View

```text
+---------------------------------------------------+
|                                                   |
|       [CAMERA APERTURE / Pinhole / Lens Barrel]   |
|                                                   |
|           [SHELL RIB / INTERNAL FRAME]           |
|                                                   |
|             [BATTERY / SERVICE AREA]              |
|                                                   |
+---------------------------------------------------+
```

### 3.3 Right Side View

```text
+-------------------------+
|                         |
|   [SCAN CONTROL]        |
|   Orange button/slider  |
|                         |
|   [HAPTIC ACTUATOR]    |
|                         |
|   [SIDE EDGE / THUMB]   |
+-------------------------+
```

### 3.4 Bottom Edge View

```text
+-----------------------------------+
|                                   |
|  [USB-C PORT]   [3.5MM JACK]      |
|                                   |
|  [STRAIN RELIEF / PORT SHIELD]    |
+-----------------------------------+
```

### 3.5 Cross-Section

```text
[Front shell / display window]
[Display support / gasket / light-control layer]
[Main PCBA]
[Shield cans / EMI cans]
[Battery pack]
[Rear shell / camera aperture / service features]
```

---

## 4. Component Placement Checklist

### Display
- [ ] Display sits in upper/front dominant region
- [ ] Display window is visible while thumb reaches the control
- [ ] Display connector path does not interfere with battery or antenna keepout

### Primary Control
- [ ] Control is reachable with one hand
- [ ] Control does not conflict with battery or display flex cables
- [ ] Mechanical travel and haptic actuator routing are defined

### Camera / OCR
- [ ] Rear aperture exists with light-tight internal path
- [ ] Lens barrel and optical path are clear of internal shell ribs
- [ ] Camera FPC path is short and shielded

### Microphones
- [ ] Acoustic ports have a defined path to mic elements
- [ ] Microphones are isolated from haptic actuator vibration
- [ ] Acoustic channels are not blocked by shell ribs

### Battery
- [ ] Battery is the dominant internal volume element
- [ ] Battery does not overlap antenna keepout or display window region
- [ ] Thermal path is defined away from mic and camera path

### Audio Jack
- [ ] Jack location is compatible with shell wall thickness and reinforcement
- [ ] Audio traces stay short and isolated from digital switching
- [ ] Removal or relocation is still possible if fit-check fails

### Antenna
- [ ] Antenna corner or edge placement is shown with copper keepout
- [ ] Hand-shadowing is considered
- [ ] Battery and shielding cans do not detune the antenna

---

## 5. Mechanical Constraints to Capture

| Area | What to Sketch | Why It Matters |
|---|---|---|
| Enclosure wall thickness | Shell walls, bosses, screw locations | Determines internal space and rigidity |
| Board outline | PCB size and edge cutout | Drives KiCad outline and keepouts |
| Port cutouts | USB-C, jack, mic opening(s) | Affects shell tooling and board placement |
| Battery height | Pouch thickness, clearance | Dominant volume driver |
| Camera aperture | Lens barrel and aperture distance | Optical alignment and light leakage |
| Display opening | Window size and bezel | Visible UI without shell flare |
| Control geometry | Button or slider travel | Tactility and one-handed use |

---

## 6. Decision Gate

Do not call the physical direction locked until this sketch shows:
- a feasible display/control relationship,
- a feasible battery/PCB/shell stack,
- a feasible camera or camera-deferred path,
- a feasible jack/port layout,
- and a KiCad board outline that reflects the shell and component constraints.

---

## 🕸️ Related Specifications and Backlinks
* **Glossary & Core Domain Language**: [[CONTEXT]]
* **Main Vault Dashboard (MOC)**: [[yadiggg_vault_overview]]
* **Physical Direction Brief**: [[physical-design/physical-direction-brief]]
* **Current BOM**: [[docs/bom-current]]