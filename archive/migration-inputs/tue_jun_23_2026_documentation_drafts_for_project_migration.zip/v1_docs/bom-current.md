---
title: "yadiggg: Current Bill of Materials (BOM) - AUTHORITATIVE"
project: yadiggg
status: authoritative
type: sourcing_specification
tags: [yadiggg, bom, sourcing, hardware, v1]
backlinks:
  - "[[CONTEXT]]"
  - "[[yadiggg_vault_overview]]"
  - "[[docs/project-state]]"
---

# yadiggg: Current Bill of Materials (BOM) - AUTHORITATIVE

**Date of Document**: Tuesday, June 24, 2026  
**Status**: AUTHORITATIVE Single Source of Truth for Part Selection  
**Revision**: V1.0  
**Purpose**: One line-item per functional block, with rationale, rejected alternatives, and KiCad symbol/footprint status.

---

## Executive Summary

This document resolves the BOM conflicts previously scattered across `docs/component-selections.md` and `yadiggg_hardware_and_electrical_integration.md`.

**Total Estimated BOM Cost (1k units)**: ~$136.30 per unit (excluding labor, NRE, packaging, assembly overhead).

**Key Reconciliation Decisions**
1. **PMIC Choice**: NXP **PCA9450B** (not AXP209).
2. **Microphone Array**: Knowles **SPH0641LM4H-1** (digital PDM, not analog SAI).
3. **Camera**: ON Semiconductor **AR1335 13MP** (retained for V1, pending fit-check).
4. **Headphone Jack**: Standard 3.5mm **CUI SJ-3523-SMT-TR** (tentative until fit-check).

---

## 1. Detailed BOM Table

### Block 1: Core Processor & Co-Processor

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 1.1 | i.MX 8M Nano SoC | NXP | MIMX8MN4DVTJZAA | BGA-486 | 1 | $22.00 | LOCKED |
| 1.2 | Cortex-M33 Co-Processor | NXP | LPC55S69JBD100 | LQFP-100 | 1 | $4.80 | LOCKED |

### Block 2: Memory

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 2.1 | LPDDR4 RAM (1GB) | Micron | MT53E512M32D2DS-046WT:D | WLCSP-170 | 1 | $8.50 | LOCKED |
| 2.2 | eMMC 5.1 Flash (32GB) | Micron | MTFC32GAPALNA-1C3 | FBGA-153 | 1 | $11.50 | LOCKED |

### Block 3: Power Management & Regulation

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 3.1 | PMIC | NXP | PCA9450BRGCR | QFN-56 | 1 | $3.50 | LOCKED |
| 3.2 | Low-Noise LDO | TI | LP5907MFX-3.3/NOPB | SOT-23-5 | 1 | $0.18 | LOCKED |
| 3.3 | Ferrite Bead | Murata | BLM15AG121SN1D | 1206 | 1 | $0.12 | LOCKED |

### Block 4: Audio Subsystem

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 4.1 | Hi-Fi DAC | ESS | ES9218PC | QFN-40 | 1 | $6.50 | LOCKED |
| 4.2 | MEMS Mic (Left) | Knowles | SPH0641LM4H-1 | LGA-5 | 1 | $1.05 | LOCKED |
| 4.3 | MEMS Mic (Right) | Knowles | SPH0641LM4H-1 | LGA-5 | 1 | $1.05 | LOCKED |
| 4.4 | 3.5mm Audio Jack | CUI | SJ-3523-SMT-TR | SMT | 1 | $0.65 | TENTATIVE |

### Block 5: Display & Visual Feedback

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 5.1 | 2.7" Memory LCD | Sharp | LS027B7DH01 | FPC | 1 | $14.00 | LOCKED |
| 5.2 | LCD SPI Mux | TI | TS3A24157DBVR | VSSOP-10 | 1 | $0.35 | LOCKED |

### Block 6: Haptic Feedback

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 6.1 | Haptic Driver | TI | DRV2605LDGSR | VSSOP-10 | 1 | $0.85 | LOCKED |
| 6.2 | 10mm LRA | Jinlong | G1040001D | Custom | 1 | $1.80 | LOCKED |

### Block 7: Imaging & Optical

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 7.1 | Image Sensor | ON Semi | AR1335 | CSP-170 | 1 | $12.50 | TENTATIVE |
| 7.2 | VCM Autofocus Driver | Dongwoon | DW9714 | WLCSP-16 | 1 | $0.80 | TENTATIVE |
| 7.3 | Macro Lens Stack | Custom | 5P-Macro-AR1335 | Barrel | 1 | $6.00 | TENTATIVE |

### Block 8: Wireless & RF

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 8.1 | Wi-Fi/BT Module | Murata | Type 1DX | LGA-44 | 1 | $6.80 | LOCKED |
| 8.2 | 2.45GHz Antenna | Johanson | 2450AT18A100E | 1206 | 1 | $0.22 | LOCKED |

### Block 9: Power Input & Battery

| Line | Part Name | Manufacturer | Part Number | Package | Qty | Unit Cost (1k) | Status |
|---:|---|---|---|---|---:|---:|---|
| 9.1 | USB-C Connector | Molex | 201267-0005 | SMT | 1 | $1.15 | LOCKED |
| 9.2 | Li-Poly Battery | Custom | LP503759-1500 | Pouch | 1 | $6.50 | LOCKED |
| 9.3 | Battery Protection IC | Generic | DW01 + 8205A | QFN/SOT | 1 | $0.25 | LOCKED |

---

## 2. Reconciled Alternatives & Decisions

| Function | Selected Part | Rejected Alternatives | Why Selected |
|---|---|---|---|
| PMIC | PCA9450B | AXP209, BD71850MWV | Better i.MX 8M Nano alignment and simpler rails |
| Audio capture | SPH0641LM4H-1 | Analog MEMS / external ADC | Direct PDM saves cost and reduces noise |
| DAC | ES9218PC | WM8994, TPA6130A2 | Better fidelity and cleaner analog path |
| Display | LS027B7DH01 | OLED, E-ink | Reflective and low power |
| Camera | AR1335 | Remove camera entirely | Retained for OCR scope until fit-check proves otherwise |
| Audio jack | SJ-3523-SMT-TR | Remove jack / side-edge variant | Keep unless space/strength fit check fails |

---

## 3. Cost Summary

| Category | Subtotal |
|---|---:|
| Core processors | $26.80 |
| Memory | $20.00 |
| Power management | $4.15 |
| Audio | $10.20 |
| Display & haptics | $16.15 |
| Camera | $19.80 |
| Wireless | $7.02 |
| Battery / power input | $8.70 |
| Passives & support | $3.48 |
| **Total** | **$136.30** |

---

## 4. Status Flags

### Locked
- Core processors, memory, PMIC, DAC, display, haptics, and wireless are currently locked.

### Tentative
- Camera subsystem and 3.5mm jack remain tentative until the placement sketch and fit-check are complete.

### Blocking Decisions
- Camera inclusion vs. removal
- 15mm enclosure thickness and port placement
- Battery stack height and board-to-shell spacing

---

## 🕸️ Related Specifications and Backlinks
* **Glossary & Core Domain Language**: [[CONTEXT]]
* **Main Vault Dashboard (MOC)**: [[yadiggg_vault_overview]]
* **Physical Direction Brief**: [[physical-design/physical-direction-brief]]
* **Hardware Integration Spec**: [[yadiggg_hardware_and_electrical_integration]]