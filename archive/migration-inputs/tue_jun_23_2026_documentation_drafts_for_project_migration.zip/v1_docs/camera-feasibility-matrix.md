---
title: "yadiggg: Camera Feasibility Matrix"
project: yadiggg
status: active-draft
type: design_decision_log
tags: [yadiggg, camera, OCR, feasibility, physical-design]
backlinks:
  - "[[CONTEXT]]"
  - "[[docs/project-state]]"
  - "[[docs/bom-current]]"
  - "[[physical-design/placement-sketch]]"
---

# yadiggg: Camera Feasibility Matrix

**Date of Document**: Tuesday, June 24, 2026  
**Status**: Design decision support document for V1 camera scope  
**Purpose**: Resolve whether the camera/OCR path remains in V1 or should be deferred.

---

## 1. Decision Question

Should **yadiggg V1** retain the OCR/camera subsystem, or should it defer camera/OCR to a later revision and focus V1 on Sonic ID + database lookup + audio preview?

---

## 2. Options Considered

| Option | Description | Expected Value | Risk |
|---|---|---|---|
| **A. Retain Camera/OCR for V1** | Keep AR1335 + lens + VCM + MIPI path in V1 | Highest differentiation and OCR utility | Highest mechanical and cost burden |
| **B. Miniaturize Camera/OCR** | Keep a reduced-scope optical path | Good compromise | Requires new optical system specs |
| **C. Defer Camera/OCR to V1.1** | Focus V1 on Sonic ID + audio + database | Lowest complexity and fastest prototype | Loses a major product story |

---

## 3. Feasibility Matrix

| Criterion | Weight | Option A | Option B | Option C |
|---|---:|---:|---:|---:|
| Space / enclosure fit | 5 | 2 | 3 | 5 |
| Optical performance | 5 | 4 | 3 | 1 |
| BOM cost | 4 | 2 | 3 | 5 |
| PCB routing complexity | 4 | 2 | 3 | 5 |
| Power draw | 3 | 2 | 3 | 5 |
| Mechanical assembly complexity | 4 | 2 | 3 | 5 |
| OCR / product value | 5 | 5 | 3 | 2 |
| Schedule / risk | 4 | 2 | 3 | 4 |

### Score Legend
- 1 = poor fit / high burden
- 3 = acceptable / moderate burden
- 5 = strong fit / low burden

---

## 4. Detailed Assessment

### Option A: Retain Camera/OCR for V1

**Pros**
- Highest differentiation from a pure audio-only device
- OCR directly supports record-store use cases
- Strong brand story for the “aim/scan/reveal” flow

**Cons**
- Adds BOM cost and routing complexity
- Requires a light-tight optical path and enclosure aperture
- May force a larger shell than desired

**Recommendation**
- Viable only if the placement sketch proves the camera module can fit in the intended enclosure.

### Option B: Miniaturize Camera/OCR

**Pros**
- Practical compromise if the full AR1335 path is too bulky
- Could preserve a reduced OCR story

**Cons**
- Requires a new optical architecture
- Lower OCR quality may weaken the product promise

### Option C: Defer Camera/OCR to V1.1

**Pros**
- Simplifies the physical envelope, PCB layout, and BOM
- Shortens the path to a working prototype

**Cons**
- Loses a core use case and weakens the “aim/scan/reveal” story

---

## 5. Current Recommendation

### Recommended Path: Option A, but with a hard fit-check gate

Proceed with the camera/OCR path for V1 only if the placement sketch proves:
1. a viable rear aperture and lens barrel fit,
2. enough internal volume for battery + PCB + shielding + lens path,
3. a short and shielded MIPI route,
4. acceptable power impact,
5. no serious conflict with control placement or port cutouts.

If any of these fail, switch to **Option C** and defer the camera to V1.1.

---

## 6. Go / No-Go Gates

### Go if all are true
- [ ] Camera aperture fits in the rear shell without breaking shell strength
- [ ] Lens path stays light-tight and mechanically stable
- [ ] MIPI FFC route is shorter than ~50mm and can be shielded
- [ ] Battery and PCB still fit in the intended envelope
- [ ] Power draw remains acceptable for 5+ hour capture sessions

### No-Go if any are true
- [ ] Rear aperture causes unacceptable shell thickness or stiffness issues
- [ ] Lens barrel conflicts with battery or display stack
- [ ] Camera subsystem increases board complexity beyond the team’s current effort budget

---

## 7. Next Actions

1. Create a rear-face camera aperture sketch and lens barrel block model.
2. Update the placement sketch with battery, PCB, and camera overlap zones.
3. Re-evaluate cost and routing after review.
4. Make a final camera decision before schematic capture begins.

---

## 🕸️ Related Specifications and Backlinks
* **Glossary & Core Domain Language**: [[CONTEXT]]
* **Main Vault Dashboard (MOC)**: [[yadiggg_vault_overview]]
* **Physical Direction Brief**: [[physical-design/physical-direction-brief]]
* **Current BOM**: [[docs/bom-current]]